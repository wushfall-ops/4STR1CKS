package cometa.xyz.utils;

public final class BuildConstants {
   public static final boolean f1 = false;

   private BuildConstants() {
   }
}
