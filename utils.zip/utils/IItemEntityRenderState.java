package cometa.xyz.utils;

public interface IItemEntityRenderState {
   boolean cometa$isOnGround();

   void cometa$setOnGround(boolean var1);
}
