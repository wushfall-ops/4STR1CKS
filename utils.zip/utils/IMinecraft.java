package cometa.xyz.utils;

import net.minecraft.client.MinecraftClient;

public interface IMinecraft {
   MinecraftClient f1 = MinecraftClient.getInstance();
}
